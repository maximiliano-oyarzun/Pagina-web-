// ============================================================
// controllers/panelController.js — Lógica del panel privado
// ============================================================
// Solo accesible si el usuario inició sesión.
// Permite registrar nuevos productos en la base de datos.
// ============================================================

const db = require('../config/db');

const panelController = {

  // ── Mostrar formulario de registro de productos ──────────
  panelForm: async (req, res) => {
    try {
      // Traemos lista de productos y lista de usuarios para el admin
      const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
      const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");

      res.render('panel', {
        usuario: req.session.usuario,
        mensaje: null,
        error: null,
        productos,
        usuarios,
        editProducto: null,
        editUsuario: null
      });
    } catch (err) {
      console.error('Error al cargar panel:', err);
      res.render('panel', { 
        usuario: req.session.usuario, 
        mensaje: null, 
        error: 'Error al cargar datos',
        productos: [],
        usuarios: [],
        editProducto: null,
        editUsuario: null
      });
    }
  },

  // ── Procesar formulario: guardar producto en la BD ────────
  panelPost: async (req, res) => {
    const { nombre, descripcion, imagen_url, precio } = req.body;

    try {
      if (!nombre || !precio) {
        const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
        const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");
        return res.render('panel', {
          usuario: req.session.usuario,
          mensaje: null,
          error: 'El nombre y el precio son obligatorios',
          productos,
          usuarios,
          editProducto: null,
          editUsuario: null
        });
      }

      const [existente] = await db.query(
        'SELECT id FROM productos WHERE nombre = ?',
        [nombre]
      );
      if (existente.length > 0) {
        const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
        const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");
        return res.render('panel', {
          usuario: req.session.usuario,
          mensaje: null,
          error: 'Ya existe un producto con ese nombre ❌',
          productos,
          usuarios,
          editProducto: null,
          editUsuario: null
        });
      }

      await db.query(
        'INSERT INTO productos (nombre, descripcion, imagen_url, precio) VALUES (?, ?, ?, ?)',
        [nombre, descripcion, imagen_url, precio]
      );

      const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
      const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");
      res.render('panel', {
        usuario: req.session.usuario,
        mensaje: 'Producto registrado exitosamente ✅',
        error: null,
        productos,
        usuarios,
        editProducto: null,
        editUsuario: null
      });

    } catch (error) {
      console.error('Error al guardar producto:', error);
      const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
      const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");
      res.render('panel', {
        usuario: req.session.usuario,
        mensaje: null,
        error: 'Error al guardar el producto, intente nuevamente ❌',
        productos,
        usuarios,
        editProducto: null,
        editUsuario: null
      });
    }
  },

  panelEditProduct: async (req, res) => {
    const productoId = req.params.id;
    try {
      const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
      const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");
      const [rows] = await db.query('SELECT * FROM productos WHERE id = ? AND activo = 1', [productoId]);
      if (rows.length === 0) return res.redirect('/panel');

      res.render('panel', {
        usuario: req.session.usuario,
        mensaje: null,
        error: null,
        productos,
        usuarios,
        editProducto: rows[0],
        editUsuario: null
      });
    } catch (err) {
      console.error('Error al cargar producto para editar:', err);
      res.redirect('/panel');
    }
  },

  panelUpdateProduct: async (req, res) => {
    const productoId = req.params.id;
    const { nombre, descripcion, imagen_url, precio } = req.body;

    try {
      if (!nombre || !precio) {
        return res.redirect('/panel');
      }

      await db.query(
        'UPDATE productos SET nombre = ?, descripcion = ?, imagen_url = ?, precio = ? WHERE id = ? AND activo = 1',
        [nombre, descripcion, imagen_url, precio, productoId]
      );

      res.redirect('/panel');
    } catch (err) {
      console.error('Error actualizando producto:', err);
      res.redirect('/panel');
    }
  },

  panelEditUser: async (req, res) => {
    const userId = req.params.id;
    try {
      const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
      const [usuarios] = await db.query("SELECT id, nombre, usuario, correo, role, creado_en FROM clientes WHERE activo = 1 ORDER BY creado_en DESC");
      const [rows] = await db.query('SELECT id, nombre, usuario, correo, role FROM clientes WHERE id = ? AND activo = 1', [userId]);
      if (rows.length === 0) return res.redirect('/panel');

      res.render('panel', {
        usuario: req.session.usuario,
        mensaje: null,
        error: null,
        productos,
        usuarios,
        editProducto: null,
        editUsuario: rows[0]
      });
    } catch (err) {
      console.error('Error al cargar usuario para editar:', err);
      res.redirect('/panel');
    }
  },

  panelUpdateUser: async (req, res) => {
    const userId = req.params.id;
    const { nombre, correo, role } = req.body;

    try {
      if (!nombre || !correo || !role) {
        return res.redirect('/panel');
      }

      await db.query(
        'UPDATE clientes SET nombre = ?, correo = ?, role = ? WHERE id = ? AND activo = 1',
        [nombre, correo, role, userId]
      );

      res.redirect('/panel');
    } catch (err) {
      console.error('Error actualizando usuario:', err);
      res.redirect('/panel');
    }
  }
};

module.exports = panelController;

