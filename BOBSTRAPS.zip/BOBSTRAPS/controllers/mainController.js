// ============================================================
// controllers/mainController.js — Lógica de vistas públicas
// ============================================================
// Los controladores contienen la lógica de negocio.
// Reciben la petición (req), consultan la BD y envían
// la respuesta (res) renderizando una vista EJS.
// ============================================================

const db = require('../config/db'); // Importamos la conexión a la BD
const { buildTransaction } = require('../config/transbank');
const checkoutStore = require('../config/checkoutStore');

const SHIPPING_OPTIONS = {
  standard: { label: 'Envío estándar', cost: 3000 },
  express: { label: 'Envío express', cost: 7000 },
  retiro: { label: 'Retiro en sucursal', cost: 0 }
};

function normalizeResponseField(result, field1, field2) {
  return result[field1] || result[field2] || null;
}

async function createWebpaySession(req, cart, clienteId, shippingAddress, shippingMethod) {
  const shipping = SHIPPING_OPTIONS[shippingMethod] || SHIPPING_OPTIONS.standard;
  const subtotal = cart.reduce((sum, item) => sum + item.precio * item.cantidad, 0);
  const total = subtotal + shipping.cost;
  const buyOrder = `BOBSTRAPS-${clienteId}-${Date.now()}`;
  const sessionId = req.sessionID || `cliente-${clienteId}-${Date.now()}`;
  const returnUrl = `${req.protocol}://${req.get('host')}/webpay/commit`;

  const [orderResult] = await db.query(
    'INSERT INTO ordenes (cliente_id, buy_order, total, shipping_address, shipping_method, shipping_cost, estado) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [clienteId, buyOrder, total, shippingAddress || '', shipping.label, shipping.cost, 'pendiente']
  );
  const orderId = orderResult.insertId;

  const transaction = buildTransaction();
  const response = await transaction.create(buyOrder, sessionId, total, returnUrl);

  checkoutStore.save(response.token, {
    clienteId,
    buyOrder,
    amount: total,
    cart: cart.map(item => ({ id: item.id, nombre: item.nombre, precio: item.precio, cantidad: item.cantidad })),
    orderId
  });

  return { response, total, buyOrder, orderId };
}

async function saveOrderDetails(orderId, clienteId, cart) {
  for (const item of cart) {
    await db.query(
      'INSERT INTO detalle_compra (orden_id, cliente_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?, ?)',
      [orderId, clienteId, item.id, item.cantidad, item.precio]
    );
    await db.query(
      'UPDATE productos SET stock = GREATEST(stock - ?, 0) WHERE id = ?',
      [item.cantidad, item.id]
    );
  }
}

async function processWebpayCommit(req) {
  const token = (req.body && req.body.token_ws) || (req.query && req.query.token_ws);
  if (!token) {
    throw new Error('No se recibió un token de pago válido desde la pasarela. El pago pudo ser cancelado.');
  }

  const checkout = checkoutStore.consume(token);
  if (!checkout) {
    throw new Error('No se encontró la sesión de pago. Por favor inicia el proceso nuevamente.');
  }

  const transaction = buildTransaction();
  let result;
  try {
    result = await transaction.commit(token);
  } catch (commitError) {
    await db.query('UPDATE ordenes SET estado = ? WHERE id = ?', ['cancelado', checkout.orderId]);
    commitError.message = `Transbank commit falló: ${commitError.message}`;
    commitError.checkout = checkout;
    throw commitError;
  }

  const paidAmount = Number(normalizeResponseField(result, 'amount', 'total') || 0);

  if (result.buy_order !== checkout.buyOrder || paidAmount !== checkout.amount) {
    await db.query('UPDATE ordenes SET estado = ? WHERE id = ?', ['cancelado', checkout.orderId]);
    const error = new Error('Inconsistencia en pago Transbank.');
    error.webpayResult = result;
    error.checkout = checkout;
    throw error;
  }

  const authorizationCode = normalizeResponseField(result, 'authorization_code', 'authorizationCode');
  const responseCode = Number(normalizeResponseField(result, 'response_code', 'responseCode')) || null;
  const paymentType = normalizeResponseField(result, 'payment_type_code', 'paymentTypeCode');
  const transactionDate = normalizeResponseField(result, 'transaction_date', 'transactionDate');

  await db.query(
    'UPDATE ordenes SET token = ?, estado = ?, payment_type = ?, authorization_code = ?, response_code = ?, transaction_date = ? WHERE id = ?',
    [token, 'completado', paymentType, authorizationCode, responseCode, transactionDate, checkout.orderId]
  );

  await saveOrderDetails(checkout.orderId, checkout.clienteId, checkout.cart);

  return { checkout, result };
}

const mainController = {

  // ── Página principal (/  y  /productos) ──────────────────
  index: async (req, res) => {
    try {
      const [productos] = await db.query('SELECT * FROM productos WHERE activo = 1 ORDER BY creado_en DESC');
      res.render('index', {
        productos,
        usuario: req.session.usuario || '',
        clienteId: req.session.clienteId || null,
        role: req.session.role || null
      });
    } catch (error) {
      console.error('Error al obtener productos:', error);
      res.render('index', { productos: [], usuario: '' });
    }
  },

  contacto: (req, res) => {
    res.render('contacto', {
      usuario: req.session.usuario || '',
      mensaje: null,
      error: null
    });
  },

  contactoPost: async (req, res) => {
    const { nombre, correo, mensaje } = req.body;
    if (!nombre || !correo || !mensaje) {
      return res.render('contacto', {
        usuario: req.session.usuario || '',
        error: 'Por favor completa todos los campos',
        mensaje: null
      });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(correo)) {
      return res.render('contacto', {
        usuario: req.session.usuario || '',
        error: 'Ingresa un correo electrónico válido',
        mensaje: null
      });
    }
    try {
      await db.query('INSERT INTO contactos (nombre, correo, mensaje) VALUES (?, ?, ?)', [nombre, correo, mensaje]);
      res.render('contacto', {
        usuario: req.session.usuario || '',
        mensaje: '✅ Mensaje enviado con éxito. Nos pondremos en contacto pronto.',
        error: null
      });
    } catch (err) {
      console.error('Error al guardar contacto:', err);
      res.render('contacto', {
        usuario: req.session.usuario || '',
        error: 'Error al enviar el mensaje. Intenta nuevamente.',
        mensaje: null
      });
    }
  },

  comprarPost: async (req, res) => {
    const { producto_id, cantidad } = req.body;
    const clienteId = req.session.clienteId;
    if (!clienteId) return res.redirect('/login');
    try {
      const qty = parseInt(cantidad, 10) || 1;
      const [prodRows] = await db.query('SELECT id, stock FROM productos WHERE id = ? AND activo = 1', [producto_id]);
      if (prodRows.length === 0) return res.redirect('/');
      if (qty > prodRows[0].stock) return res.redirect('/cart');
      await db.query('INSERT INTO detalle_compra (cliente_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)', [clienteId, producto_id, qty, 0]);
      res.redirect('/');
    } catch (err) {
      console.error('Error al procesar compra:', err);
      res.redirect('/');
    }
  },

  cartAdd: async (req, res) => {
    const { producto_id, cantidad } = req.body || {};
    const clienteId = req.session.clienteId;
    if (!clienteId) return res.status(401).json({ success: false, message: 'Debes iniciar sesión' });
    try {
      const qty = parseInt(cantidad, 10) || 1;
      const [rows] = await db.query('SELECT id, nombre, precio, imagen_url, stock FROM productos WHERE id = ? AND activo = 1', [producto_id]);
      if (rows.length === 0) return res.status(404).json({ success: false, message: 'Producto no encontrado' });
      const p = rows[0];
      if (qty > p.stock) {
        return res.status(400).json({ success: false, message: `Solo quedan ${p.stock} unidades de ${p.nombre}` });
      }
      if (!req.session.cart) req.session.cart = [];
      const existing = req.session.cart.find(i => i.id === p.id);
      if (existing) {
        if (existing.cantidad + qty > p.stock) {
          const message = `No puedes agregar más de ${p.stock} unidades de este producto`;
          if (req.headers.accept && req.headers.accept.includes('html')) {
            return res.redirect(`/product/${p.id}?error=${encodeURIComponent(message)}`);
          }
          return res.status(400).json({ success: false, message });
        }
        existing.cantidad += qty;
      } else {
        req.session.cart.push({ id: p.id, nombre: p.nombre, precio: p.precio, imagen_url: p.imagen_url, cantidad: qty });
      }
      req.session.save(() => {
        if (req.headers.accept && req.headers.accept.includes('html')) {
          return res.redirect('/cart');
        }
        res.json({ success: true, message: `${p.nombre} agregado al carrito ✅`, producto: p.nombre, cantidad: qty });
      });
    } catch (err) {
      console.error('Error añadiendo al carrito:', err);
      if (req.headers.accept && req.headers.accept.includes('html')) {
        return res.redirect('/cart');
      }
      res.status(500).json({ success: false, message: 'Error al agregar al carrito' });
    }
  },

  cartView: (req, res) => {
    const cart = req.session.cart || [];
    const total = cart.reduce((s, it) => s + (it.precio * it.cantidad), 0);
    res.render('cart', { usuario: req.session.usuario || '', cart, total, error: null });
  },

  cartRemove: (req, res) => {
    const { producto_id } = req.body;
    if (!req.session.cart) return res.redirect('/cart');
    req.session.cart = req.session.cart.filter(i => String(i.id) !== String(producto_id));
    req.session.save(() => res.redirect('/cart'));
  },

  cartCheckout: async (req, res) => {
    const clienteId = req.session.clienteId;
    const cart = req.session.cart || [];
    if (!clienteId) return res.redirect('/login');
    if (cart.length === 0) return res.redirect('/cart');
    const { shipping_address, shipping_method } = req.body;
    if (!shipping_address || !shipping_method) {
      const total = cart.reduce((s, it) => s + (it.precio * it.cantidad), 0);
      return res.render('cart', {
        usuario: req.session.usuario || '',
        cart,
        total,
        error: 'Agrega una dirección de envío y elige un método para continuar.'
      });
    }
    try {
      const validMethods = ['standard', 'express', 'retiro'];
      const method = validMethods.includes(shipping_method) ? shipping_method : 'standard';
      const { response, total, buyOrder, orderId } = await createWebpaySession(req, cart, clienteId, shipping_address, method);
      res.render('transbankRedirect', {
        usuario: req.session.usuario || '',
        url: response.url,
        token: response.token,
        amount: total,
        buyOrder,
        orderId
      });
    } catch (err) {
      console.error('Error iniciando pago Transbank:', err);
      const total = cart.reduce((s, it) => s + (it.precio * it.cantidad), 0);
      res.render('cart', {
        usuario: req.session.usuario || '',
        cart,
        total,
        error: 'No se pudo iniciar el pago. Intenta nuevamente más tarde.'
      });
    }
  },

  webpayCreate: async (req, res) => {
    const clienteId = req.session.clienteId;
    const cart = req.session.cart || [];
    if (!clienteId) return res.status(401).json({ success: false, message: 'Debes iniciar sesión' });
    if (cart.length === 0) return res.status(400).json({ success: false, message: 'El carrito está vacío' });
    try {
      const { response, total, buyOrder } = await createWebpaySession(req, cart, clienteId, '', 'standard');
      return res.json({ success: true, url: response.url, token: response.token, amount: total, buyOrder });
    } catch (err) {
      console.error('Error creando sesión Webpay:', err);
      return res.status(500).json({ success: false, message: 'No se pudo iniciar el pago con Transbank' });
    }
  },

  cartCheckoutReturn: async (req, res) => {
    try {
      const { checkout, result } = await processWebpayCommit(req);
      if (req.session && req.session.clienteId === checkout.clienteId) {
        req.session.cart = [];
        req.session.save(() => {
          res.render('checkout_success', {
            usuario: req.session.usuario || '',
            commit: result,
            items: checkout.cart,
            total: checkout.amount,
            orderId: checkout.orderId
          });
        });
      } else {
        res.render('checkout_success', {
          usuario: req.session ? req.session.usuario || '' : '',
          commit: result,
          items: checkout.cart,
          total: checkout.amount,
          orderId: checkout.orderId
        });
      }
    } catch (err) {
      console.error('Error confirmando pago Transbank:', err);
      res.render('checkout_error', {
        usuario: req.session ? req.session.usuario || '' : '',
        message: err.message || 'Ocurrió un error al confirmar el pago. Intenta nuevamente o comunícate con tu banco.'
      });
    }
  },

  productDetail: async (req, res) => {
    try {
      const productoId = req.params.id;
      const [rows] = await db.query('SELECT * FROM productos WHERE id = ? AND activo = 1', [productoId]);
      if (rows.length === 0) return res.redirect('/');
      res.render('productDetail', {
        usuario: req.session.usuario || '',
        producto: rows[0],
        clienteId: req.session.clienteId || null
      });
    } catch (err) {
      console.error('Error cargando detalle de producto:', err);
      res.redirect('/');
    }
  },

  orderHistory: async (req, res) => {
    try {
      const clienteId = req.session.clienteId;
      const [ordenes] = await db.query(
        'SELECT id, buy_order, total, shipping_method, shipping_cost, estado, transaction_date, created_at FROM ordenes WHERE cliente_id = ? ORDER BY created_at DESC',
        [clienteId]
      );
      res.render('mis_ordenes', { usuario: req.session.usuario || '', ordenes });
    } catch (err) {
      console.error('Error obteniendo órdenes:', err);
      res.redirect('/');
    }
  },

  orderDetail: async (req, res) => {
    try {
      const clienteId = req.session.clienteId;
      const orderId = req.params.id;
      const [orders] = await db.query('SELECT * FROM ordenes WHERE id = ? AND cliente_id = ?', [orderId, clienteId]);
      if (orders.length === 0) return res.redirect('/mis-ordenes');
      const order = orders[0];
      const [items] = await db.query(
        'SELECT dc.*, p.nombre, p.imagen_url FROM detalle_compra dc JOIN productos p ON dc.producto_id = p.id WHERE dc.orden_id = ?',
        [orderId]
      );
      res.render('order_detail', { usuario: req.session.usuario || '', order, items });
    } catch (err) {
      console.error('Error obteniendo detalle de orden:', err);
      res.redirect('/mis-ordenes');
    }
  },

  orderInvoice: async (req, res) => {
    try {
      const clienteId = req.session.clienteId;
      const orderId = req.params.id;
      const [orders] = await db.query('SELECT * FROM ordenes WHERE id = ? AND cliente_id = ?', [orderId, clienteId]);
      if (orders.length === 0) return res.redirect('/mis-ordenes');
      const order = orders[0];
      const [items] = await db.query(
        'SELECT dc.*, p.nombre FROM detalle_compra dc JOIN productos p ON dc.producto_id = p.id WHERE dc.orden_id = ?',
        [orderId]
      );
      res.setHeader('Content-Disposition', `attachment; filename=boleta-${orderId}.html`);
      res.render('invoice', { usuario: req.session.usuario || '', order, items });
    } catch (err) {
      console.error('Error generando boleta:', err);
      res.redirect('/mis-ordenes');
    }
  },

  requestForm: async (req, res) => {
    try {
      const clienteId = req.session.clienteId;
      const [ordenes] = await db.query('SELECT id, buy_order FROM ordenes WHERE cliente_id = ? AND estado = ?', [clienteId, 'completado']);
      const [items] = await db.query(
        'SELECT dc.id, dc.orden_id, dc.producto_id, p.nombre FROM detalle_compra dc JOIN productos p ON dc.producto_id = p.id WHERE dc.cliente_id = ?',
        [clienteId]
      );
      res.render('request_form', { usuario: req.session.usuario || '', ordenes, items, error: null, success: null });
    } catch (err) {
      console.error('Error cargando formulario de solicitudes:', err);
      res.redirect('/mis-ordenes');
    }
  },

  requestPost: async (req, res) => {
    try {
      const clienteId = req.session.clienteId;
      const { orden_id, producto_id, tipo, motivo, descripcion } = req.body;
      const [ordenes] = await db.query('SELECT id, buy_order FROM ordenes WHERE cliente_id = ? AND estado = ?', [clienteId, 'completado']);
      const [items] = await db.query(
        'SELECT dc.id, dc.orden_id, dc.producto_id, p.nombre FROM detalle_compra dc JOIN productos p ON dc.producto_id = p.id WHERE dc.cliente_id = ?',
        [clienteId]
      );
      if (!orden_id || !producto_id || !tipo || !motivo || !descripcion) {
        return res.render('request_form', {
          usuario: req.session.usuario || '',
          ordenes,
          items,
          error: 'Completa todos los campos para enviar la solicitud.',
          success: null
        });
      }
      await db.query(
        'INSERT INTO solicitudes (cliente_id, orden_id, producto_id, tipo, motivo, descripcion) VALUES (?, ?, ?, ?, ?, ?)',
        [clienteId, orden_id, producto_id, tipo, motivo, descripcion]
      );
      res.render('request_form', {
        usuario: req.session.usuario || '',
        ordenes,
        items,
        error: null,
        success: 'Solicitud enviada correctamente. Nuestro equipo revisará tu caso.'
      });
    } catch (err) {
      console.error('Error guardando solicitud:', err);
      res.redirect('/mis-ordenes');
    }
  },

  requestList: async (req, res) => {
    try {
      const clienteId = req.session.clienteId;
      const [requests] = await db.query(
        `SELECT s.*, o.buy_order, p.nombre AS producto_nombre
         FROM solicitudes s
         JOIN ordenes o ON s.orden_id = o.id
         JOIN productos p ON s.producto_id = p.id
         WHERE s.cliente_id = ?
         ORDER BY s.creado_en DESC`,
        [clienteId]
      );
      res.render('request_list', { usuario: req.session.usuario || '', solicitudes: requests });
    } catch (err) {
      console.error('Error obteniendo solicitudes:', err);
      res.redirect('/mis-ordenes');
    }
  },

  registro: (req, res) => {
    res.render('registro', {
      usuario: req.session.usuario || ''
    });
  }

};

module.exports = mainController;
