// controllers/authController.js — Logica de autenticacion

const db      = require('../config/db');
const bcrypt  = require('bcryptjs');

const authController = {

  // Muestra el formulario de login
  loginForm: (req, res) => {
    if (req.session && req.session.usuario) {
      if (req.session.role === 'admin') return res.redirect('/panel');
      return res.redirect('/');
    }
    res.render('login', { error: null, usuario: '' });
  },

  // Procesa el formulario: valida usuario y clave contra la BD
  loginPost: async (req, res) => {
    const { usuario, clave } = req.body;

    // Validacion basica: campos no vacios
    if (!usuario || !clave) {
      return res.render('login', { error: 'Ingresa usuario y contrasena', usuario: '' });
    }

    try {
      // Buscamos el usuario en la tabla clientes
      const [rows] = await db.query(
        'SELECT * FROM clientes WHERE usuario = ?',
        [usuario]
      );

      // Si no existe el usuario en la BD
      if (rows.length === 0) {
        return res.render('login', { error: 'Credenciales incorrectas', usuario: '' });
      }

      const cliente = rows[0];

      // Intentamos comparar con bcrypt (clave hasheada)
      let claveCorrecta = false;

      // Si la clave guardada empieza con $2 es un hash bcrypt
      if (cliente.clave.startsWith('$2')) {
        claveCorrecta = await bcrypt.compare(clave, cliente.clave);
      } else {
        // Si no esta hasheada, comparamos directo (solo para pruebas)
        claveCorrecta = (clave === cliente.clave);
      }

      if (!claveCorrecta) {
        return res.render('login', { error: 'Credenciales incorrectas', usuario: '' });
      }

      // Credenciales correctas: guardamos en sesion
      req.session.usuario   = cliente.nombre;
      req.session.clienteId = cliente.id;
      // Guardamos rol para controlar permisos (admin vs user)
      // Si la columna role no existe en la BD, asumimos 'user'
      req.session.role = cliente.role || (cliente.usuario === 'admin' ? 'admin' : 'user');

      // Log de depuración mínimo para verificar flujo
      console.log('Login OK:', { usuario: cliente.usuario, nombre: cliente.nombre, id: cliente.id, role: req.session.role });

      // Guardamos la sesión explícitamente antes de redirigir
      req.session.save((saveErr) => {
        if (saveErr) {
          console.error('Error guardando sesión después de login:', saveErr);
          return res.render('login', { error: 'Error guardando sesión, inténtalo de nuevo', usuario: '' });
        }

        // Redirigimos según el rol: admin → panel, user → inicio/tienda
        if (req.session.role === 'admin') {
          return res.redirect('/panel');
        } else {
          return res.redirect('/');
        }
      });

    } catch (err) {
      console.error('Error en login:', err);
      res.render('login', { error: 'Error del servidor: ' + err.message, usuario: '' });
    }
  },

  // Procesa el registro de nuevos usuarios (POST /registro)
  registerPost: async (req, res) => {
    const { username, email, password, confirm } = req.body;

    // Validación básica del lado del servidor
    if (!username || !email || !password || !confirm) {
      return res.render('registro', { error: 'Completa todos los campos para registrarte', usuario: '' });
    }
    if (password !== confirm) {
      return res.render('registro', { error: 'Las contraseñas no coinciden', usuario: '' });
    }

    try {
      // Verificamos que no exista un usuario con ese nombre
      const [ex] = await db.query('SELECT id FROM clientes WHERE usuario = ?', [username]);
      if (ex.length > 0) {
        return res.render('registro', { error: 'El nombre de usuario ya está en uso, elige otro', usuario: '' });
      }

      // Hasheamos la contraseña y guardamos el nuevo cliente con rol 'user'
      const hash = await bcrypt.hash(password, 10);

      await db.query(
        'INSERT INTO clientes (nombre, usuario, clave, correo, role) VALUES (?, ?, ?, ?, ?)',
        [username, username, hash, email, 'user']
      );

      // Mostramos la misma vista de registro con un mensaje de éxito
      // para que el cliente muestre el modal (sin forzar redirección).
      return res.render('registro', {
        usuario: '',
        error: null,
        success: true,
        successUser: username
      });

    } catch (err) {
      console.error('Error en registro:', err);
      res.render('registro', { error: 'Error del servidor: ' + err.message, usuario: '' });
    }
  },

  // Cierra la sesion
  logout: (req, res) => {
    req.session.destroy(() => {
      res.redirect('/');
    });
  }

  ,

  // Muestra la página de cuenta (cambiar contraseña)
  accountForm: (req, res) => {
    if (!req.session || !req.session.usuario) return res.redirect('/login');
    res.render('account', { usuario: req.session.usuario, error: null, mensaje: null });
  },

  // Procesa cambio de contraseña
  changePasswordPost: async (req, res) => {
    if (!req.session || !req.session.clienteId) return res.redirect('/login');
    const { current_password, new_password, confirm_password } = req.body;
    if (!current_password || !new_password || !confirm_password) {
      return res.render('account', { usuario: req.session.usuario, error: 'Completa todos los campos', mensaje: null });
    }
    if (new_password !== confirm_password) {
      return res.render('account', { usuario: req.session.usuario, error: 'Las contraseñas nuevas no coinciden', mensaje: null });
    }

    try {
      const [rows] = await db.query('SELECT clave FROM clientes WHERE id = ?', [req.session.clienteId]);
      if (rows.length === 0) return res.redirect('/login');
      const cliente = rows[0];
      let ok = false;
      if (cliente.clave.startsWith('$2')) {
        ok = await bcrypt.compare(current_password, cliente.clave);
      } else {
        ok = current_password === cliente.clave;
      }
      if (!ok) return res.render('account', { usuario: req.session.usuario, error: 'Contraseña actual incorrecta', mensaje: null });

      const hash = await bcrypt.hash(new_password, 10);
      await db.query('UPDATE clientes SET clave = ? WHERE id = ?', [hash, req.session.clienteId]);
      res.render('account', { usuario: req.session.usuario, error: null, mensaje: 'Contraseña actualizada correctamente' });
    } catch (err) {
      console.error('Error cambiando contraseña:', err);
      res.render('account', { usuario: req.session.usuario, error: 'Error del servidor', mensaje: null });
    }
  }

};

module.exports = authController;
