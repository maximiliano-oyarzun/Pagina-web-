require('dotenv').config();
const express = require('express');         // Framework web principal
const session = require('express-session'); // Para manejar sesiones de usuario
const path = require('path');               // Para manejar rutas de archivos

const app = express(); // Creamos la aplicación Express

// ── Motor de vistas ──────────────────────────────────────────
// EJS es un motor de plantillas: nos permite mezclar HTML con
// datos dinámicos usando etiquetas como <%= variable %>
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); // Carpeta de vistas

// ── Archivos estáticos ───────────────────────────────────────
// Sirve los archivos de la carpeta /assets (CSS, JS, imágenes)
// directamente al navegador sin pasar por las rutas.
app.use('/assets', express.static(path.join(__dirname, 'assets')));

// ── Middlewares para leer datos del formulario ────────────────
// Estos middlewares procesan los datos que envía el usuario
// desde los formularios HTML (método POST).
app.use(express.urlencoded({ extended: true })); // Formularios HTML
app.use(express.json());                          // Datos JSON

// ── Sesiones ─────────────────────────────────────────────────
// Las sesiones permiten "recordar" al usuario entre peticiones.
// Por ejemplo, si inició sesión, la sesión guarda ese dato.
const sessionCookieOptions = {
  maxAge: 1000 * 60 * 60, // La sesión dura 1 hora
};

if (process.env.NODE_ENV === 'production') {
  sessionCookieOptions.sameSite = 'none';
  sessionCookieOptions.secure = true;
} else {
  sessionCookieOptions.sameSite = 'lax';
  sessionCookieOptions.secure = false;
}

app.use(session({
  secret: 'bobstraps_secreto_2024', // Clave para cifrar la sesión
  resave: false,                     // No guardar si no hubo cambios
  saveUninitialized: false,          // No crear sesión vacía
  cookie: sessionCookieOptions
}));

// Hacer los datos de sesión accesibles en todas las vistas (header etc.)
app.use((req, res, next) => {
  res.locals.usuario = req.session ? req.session.usuario : null;
  res.locals.role = req.session ? req.session.role : null;
  next();
});

// ── Rutas ─────────────────────────────────────────────────────
// Importamos y registramos los archivos de rutas.
// Cada archivo maneja un grupo de URLs relacionadas.
const mainRoutes = require('./routes/main');   // Rutas principales (/, /contacto)
const authRoutes = require('./routes/auth');   // Rutas de autenticación (/login)
const panelRoutes = require('./routes/panel'); // Rutas del panel privado (/panel)

app.use('/', mainRoutes);   // Rutas públicas
app.use('/', authRoutes);   // Rutas de login/logout
app.use('/', panelRoutes);  // Rutas del panel (protegido)

// ── Iniciar servidor ──────────────────────────────────────────
const PORT = process.env.PORT || 3000; // Puerto en el que escucha el servidor
app.listen(PORT, () => {
  console.log(`✅ BOBSTRAPS corriendo en http://localhost:${PORT}`);
});
