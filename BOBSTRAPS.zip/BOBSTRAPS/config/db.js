// ============================================================
// config/db.js — Conexión a la base de datos MySQL
// ============================================================
// Usamos mysql2 para conectarnos a MySQL/MariaDB.
// createPool crea un "pool" (conjunto) de conexiones reutilizables,
// lo que es más eficiente que abrir una conexión nueva cada vez.
// ============================================================

const mysql = require('mysql2');

// Creamos el pool con los datos de conexión
const pool = mysql.createPool({
  host: '10.0.6.39',       // Servidor de base de datos (en tu PC local)
  user: 'estudiante',            // Usuario de MySQL (cámbialo si es diferente)
  password: 'Informatica-165',            // Contraseña de MySQL (cámbiala si tienes una)
  database: 'TiendaJO',          // Nombre de la base de datos
  waitForConnections: true, // Esperar si no hay conexiones disponibles
  connectionLimit: 10,      // Máximo 10 conexiones simultáneas
  queueLimit: 0             // Sin límite en la cola de espera
});

// .promise() nos permite usar async/await en vez de callbacks
module.exports = pool.promise();
