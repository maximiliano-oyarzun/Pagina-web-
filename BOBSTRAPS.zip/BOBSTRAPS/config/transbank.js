const { IntegrationCommerceCodes, IntegrationApiKeys, WebpayPlus } = require('transbank-sdk');

const envName = (process.env.TRANSBANK_ENV || 'integration').trim().toLowerCase();
const isProduction = envName === 'production';
const commerceCode = process.env.TRANSBANK_COMMERCE_CODE || IntegrationCommerceCodes.WEBPAY_PLUS;
const apiKey = process.env.TRANSBANK_API_KEY || IntegrationApiKeys.WEBPAY;

function buildTransaction() {
  if (isProduction) {
    return WebpayPlus.Transaction.buildForProduction(commerceCode, apiKey);
  }
  return WebpayPlus.Transaction.buildForIntegration(commerceCode, apiKey);
}

module.exports = {
  buildTransaction,
  commerceCode,
  apiKey,
  envName,
  isProduction
};
