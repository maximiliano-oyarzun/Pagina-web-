const store = new Map();

function save(token, data) {
  if (!token) return;
  store.set(token, { ...data, createdAt: Date.now() });
}

function consume(token) {
  if (!store.has(token)) return null;
  const data = store.get(token);
  store.delete(token);
  return data;
}

function cleanup(maxAgeMs = 1000 * 60 * 15) {
  const now = Date.now();
  for (const [token, value] of store.entries()) {
    if (now - value.createdAt > maxAgeMs) store.delete(token);
  }
}

setInterval(() => cleanup(), 1000 * 60 * 5);

module.exports = {
  save,
  consume
};
