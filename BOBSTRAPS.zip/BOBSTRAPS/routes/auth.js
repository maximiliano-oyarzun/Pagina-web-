// ============================================================
// routes/auth.js — Rutas de autenticación
// ============================================================
//   GET  /login  → Muestra el formulario de login
//   POST /login  → Procesa el formulario y verifica credenciales
//   GET  /logout → Cierra la sesión del usuario
// ============================================================

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Muestra el formulario de inicio de sesión
router.get('/login', authController.loginForm);

// Procesa el login: valida usuario y clave contra la base de datos
router.post('/login', authController.loginPost);

// Procesa el registro de nuevos usuarios
router.post('/registro', authController.registerPost);

// Página de cuenta (cambiar contraseña)
router.get('/mi-cuenta', (req, res) => {
	if (!req.session || !req.session.usuario) return res.redirect('/login');
	authController.accountForm(req, res);
});

router.post('/mi-cuenta/password', (req, res) => {
	if (!req.session || !req.session.usuario) return res.redirect('/login');
	authController.changePasswordPost(req, res);
});

// Cierra la sesión y redirige al inicio
router.get('/logout', authController.logout);

module.exports = router;
