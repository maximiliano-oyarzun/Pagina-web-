// ============================================================
// routes/panel.js — Rutas del panel privado
// ============================================================
//   GET  /panel → Muestra el formulario para agregar productos
//   POST /panel → Guarda el nuevo producto en la base de datos
// ============================================================

const express = require('express');
const router = express.Router();
const panelController = require('../controllers/panelController');

// Middleware de protección: verifica que el usuario haya iniciado sesión.
// Si no está autenticado, redirige al login.
// Este middleware se aplica SOLO a las rutas de panel.
// Middleware que exige usuario con rol 'admin'
function requireAdmin(req, res, next) {
  if (req.session && req.session.usuario && req.session.role === 'admin') {
    next(); // ✅ Es admin, continúa
  } else {
    // Si no es admin, lo redirigimos a la página principal
    res.redirect('/');
  }
}

// Aplicamos el middleware de protección a rutas del admin
router.get('/panel', requireAdmin, panelController.panelForm);
router.post('/panel', requireAdmin, panelController.panelPost);
router.get('/panel/product/:id/edit', requireAdmin, panelController.panelEditProduct);
router.post('/panel/product/:id/update', requireAdmin, panelController.panelUpdateProduct);
router.get('/panel/user/:id/edit', requireAdmin, panelController.panelEditUser);
router.post('/panel/user/:id/update', requireAdmin, panelController.panelUpdateUser);

// Eliminar usuario (solo admin)
router.post('/panel/delete-user', requireAdmin, async (req, res) => {
  const { id } = req.body;
  try {
    // No permitir borrar al admin
    const [rows] = await require('../config/db').query('SELECT usuario FROM clientes WHERE id = ?', [id]);
    if (rows.length === 0) return res.redirect('/panel');
    if (rows[0].usuario === 'admin') return res.redirect('/panel');

    // Soft-delete: marcamos activo = 0
    await require('../config/db').query('UPDATE clientes SET activo = 0 WHERE id = ?', [id]);
    res.redirect('/panel');
  } catch (err) {
    console.error('Error al eliminar usuario:', err);
    res.redirect('/panel');
  }
});

// Eliminar producto (solo admin)
router.post('/panel/delete-product', requireAdmin, async (req, res) => {
  const { id } = req.body;
  try {
    // Soft-delete producto
    await require('../config/db').query('UPDATE productos SET activo = 0 WHERE id = ?', [id]);
    res.redirect('/panel');
  } catch (err) {
    console.error('Error al eliminar producto:', err);
    res.redirect('/panel');
  }
});

module.exports = router;
