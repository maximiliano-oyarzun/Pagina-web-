// ============================================================
// routes/main.js — Rutas públicas de la tienda
// ============================================================
// Aquí se definen las URLs accesibles para todos los visitantes:
//   GET /          → Página principal con productos
//   GET /productos → Sección de productos
//   GET /contacto  → Formulario de contacto
// ============================================================

const express = require('express');
const router = express.Router(); // Creamos un "mini-servidor" de rutas
const mainController = require('../controllers/mainController');

// Middleware para rutas que requieren login
function requireLogin(req, res, next) {
	if (req.session && req.session.usuario) return next();
	res.redirect('/login');
}

// Página principal: muestra la tienda con los productos
router.get('/', mainController.index);

// Sección de productos (ancla, misma vista que /)
router.get('/productos', mainController.index);

// Página de contacto: muestra el formulario
router.get('/contacto', mainController.contacto);

// Procesar formulario de contacto
router.post('/contacto', mainController.contactoPost);

// Página de registro (Actividad 3.2 — DOM y formularios)
router.get('/registro', mainController.registro);

// Comprar producto (POST) — requiere estar autenticado
router.post('/comprar', requireLogin, mainController.comprarPost);

// Carrito: añadir, ver, remover y checkout
router.post('/cart/add', requireLogin, mainController.cartAdd);
router.get('/cart', requireLogin, mainController.cartView);
router.post('/cart/remove', requireLogin, mainController.cartRemove);
router.post('/cart/checkout', requireLogin, mainController.cartCheckout);
router.all('/cart/checkout/return', mainController.cartCheckoutReturn);

// Detalle de producto y pedidos
router.get('/product/:id', mainController.productDetail);
router.get('/mis-ordenes', requireLogin, mainController.orderHistory);
router.get('/orden/:id', requireLogin, mainController.orderDetail);
router.get('/orden/:id/boleta', requireLogin, mainController.orderInvoice);

// Solicitudes de devolución, cambio y soporte
router.get('/solicitud', requireLogin, mainController.requestForm);
router.post('/solicitud', requireLogin, mainController.requestPost);
router.get('/solicitudes', requireLogin, mainController.requestList);

// Transbank Webpay Plus: endpoints oficiales
router.post('/webpay/create', requireLogin, mainController.webpayCreate);
router.all('/webpay/commit', mainController.cartCheckoutReturn);

// Exportamos el router para usarlo en app.js
module.exports = router;
