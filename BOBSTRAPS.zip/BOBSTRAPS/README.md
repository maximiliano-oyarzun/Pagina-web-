# 🏋️ BOBSTRAPS — Tienda Virtual de Gimnasio

Aplicación web de tienda de artículos de gimnasio. Desarrollada con **Node.js + Express + EJS + MySQL**.

---

## 📁 Estructura del Proyecto

```
BOBSTRAPS/
├── assets/
│   ├── css/style.css       ← Estilos (CSS)
│   └── js/main.js          ← JavaScript del cliente (validaciones)
├── config/
│   └── db.js               ← Conexión a MySQL
├── controllers/
│   ├── mainController.js   ← Lógica de páginas públicas
│   ├── authController.js   ← Lógica de login/logout
│   └── panelController.js  ← Lógica del panel privado
├── routes/
│   ├── main.js             ← Rutas públicas (/, /contacto)
│   ├── auth.js             ← Rutas de login (/login, /logout)
│   └── panel.js            ← Rutas del panel (/panel)
├── views/
│   ├── partials/
│   │   ├── header.ejs      ← Navbar reutilizable
│   │   └── footer.ejs      ← Footer reutilizable
│   ├── index.ejs           ← Página principal
│   ├── contacto.ejs        ← Formulario de contacto
│   ├── login.ejs           ← Inicio de sesión
│   └── panel.ejs           ← Panel de administración
├── app.js                  ← Servidor principal
├── package.json            ← Dependencias del proyecto
└── DB_Tienda_BOBSTRAPS.sql ← Base de datos con datos de ejemplo
```

---

## ⚙️ Instalación y configuración

### 1. Requisitos previos
- Node.js v18+
- pnpm (`npm install -g pnpm`)
- MySQL o MariaDB corriendo localmente
- Visual Studio Code
- DBeaver (para gestionar la BD)

### 2. Configurar la base de datos

1. Abre **DBeaver**
2. Conéctate a tu servidor MySQL local
3. Abre el archivo `DB_Tienda_BOBSTRAPS.sql`
4. Ejecuta todo el script (Ctrl+A → ejecutar)

Esto creará la base de datos **Tienda** con tablas y datos de ejemplo.

### 3. Configurar la conexión

Abre `config/db.js` y edita si es necesario:

```js
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',        // ← Tu usuario MySQL
  password: '',        // ← Tu contraseña MySQL
  database: 'Tienda'
});
```

### 4. Instalar dependencias

```bash
# En la carpeta del proyecto:
pnpm install
```

### 5. Ejecutar el servidor

```bash
# Modo normal
pnpm start

# Modo desarrollo (se reinicia automáticamente al guardar cambios)
pnpm dev
```

### 6. Abrir en el navegador

👉 http://localhost:3000

---

## 🔐 Credenciales de prueba

| Campo    | Valor    |
|----------|----------|
| Usuario  | admin    |
| Clave    | admin123 |

---

## 🗺️ Rutas disponibles

| Ruta       | Descripción                        |
|------------|------------------------------------|
| `/`        | Página principal con productos     |
| `/contacto`| Formulario de contacto             |
| `/login`   | Inicio de sesión                   |
| `/logout`  | Cerrar sesión                      |
| `/panel`   | Panel privado (requiere login)     |

---

## 🚀 Tecnologías usadas

- **Express.js v5.2.1** — Servidor web y enrutamiento
- **EJS v6.0.1** — Motor de plantillas HTML dinámicas
- **MySQL2 v3.22.5** — Conexión a base de datos asincrónica
- **bcryptjs v3.0.3** — Cifrado de contraseñas
- **express-session v1.19.0** — Manejo de sesiones de usuario
- **transbank-sdk v6.1.1** — Integración de pasarela de pago (Webpay Plus)
- **dotenv v16.3.1** — Gestión de variables de entorno

---

## 💳 Integración Transbank Webpay Plus

El proyecto incluye integración completa con la pasarela de pago **Transbank Webpay Plus**:

### Características:
- ✅ Flujo de pago seguro y PCI-DSS compliant
- ✅ Soporte para entorno de integración (sandbox) y producción
- ✅ Validación de montos y órdenes de compra
- ✅ Persistencia de transacciones en base de datos
- ✅ Manejo de errores robusto con try/catch

### Configuración:

Crea un archivo `.env` en la raíz del proyecto:

```env
TRANSBANK_ENV=integration
TRANSBANK_COMMERCE_CODE=597055555532
TRANSBANK_API_KEY=597055555532597055555532597055555532597055555532
NODE_ENV=development
PORT=3000
```

### Rutas de pago:
- `POST /cart/checkout` — Inicia el pago (renderiza formulario de confirmación)
- `POST /webpay/create` — Endpoint JSON para crear transacción
- `ALL /webpay/commit` — Callback de retorno desde Transbank

---

## 🔐 Credenciales de prueba

| Campo    | Valor    |
|----------|----------|
| Usuario  | admin    |
| Clave    | admin123 |

### Prueba de pago (Webpay Plus - Integración):
- Número de tarjeta: `4239000000000000`
- RUT: `11.111.111-1`
- Clave: `123`
- Vencimiento: `12/25`

---

## 🗺️ Rutas disponibles

### Públicas:
| Ruta       | Método | Descripción                        |
|------------|--------|-------|
| `/`        | GET    | Página principal con productos     |
| `/contacto`| GET    | Formulario de contacto             |
| `/login`   | GET/POST | Inicio de sesión                |
| `/logout`  | GET    | Cerrar sesión                      |
| `/registro`| GET/POST | Registro de nuevos usuarios     |

### Privadas (requieren sesión):
| Ruta       | Método | Descripción                        |
|------------|--------|-------|
| `/cart`    | GET    | Ver carrito de compras              |
| `/cart/add`| POST   | Agregar producto al carrito (AJAX) |
| `/cart/remove` | POST | Remover producto del carrito    |
| `/cart/checkout` | POST | Iniciar proceso de pago        |
| `/mi-cuenta` | GET/POST | Perfil y cambio de contraseña |

### Admin (requieren rol admin):
| Ruta       | Método | Descripción                        |
|------------|--------|-------|
| `/panel`   | GET/POST | Panel de administración          |
| `/panel/product/:id/edit` | GET | Editar producto            |
| `/panel/product/:id/update` | POST | Guardar cambios producto   |
| `/panel/product/:id/delete` | POST | Eliminar producto          |
| `/panel/user/:id/edit` | GET | Editar usuario               |
| `/panel/user/:id/update` | POST | Guardar cambios usuario    |
| `/panel/delete-user` | POST | Eliminar usuario           |

---

## 🔑 Sistema de Autenticación

### Registro
- Validación de campos con HTML5 (`required`, `minlength`, `email`)
- Verificación de unicidad del usuario
- Contraseña hasheada con bcryptjs
- Rol automático: `user` para nuevos registros, `admin` solo para usuario predeterminado

### Login
- Validación de credenciales contra base de datos
- Comparación segura de contraseñas con bcryptjs
- Sesión persistente con express-session
- Redirección según rol (admin → panel, user → inicio)

### Logout
- Destrucción completa de la sesión
- Redirección a página de inicio

### Protección de rutas
- Middleware `requireLogin`: Verifica sesión activa
- Middleware `requireAdmin`: Verifica rol admin
- Todas las rutas privadas están protegidas

---

## 📊 Funcionalidades CRUD

### Productos (Admin)
- **Create**: Formulario para agregar productos con nombre, descripción, imagen, precio
- **Read**: Visualización en vitrina pública y listado en panel
- **Update**: Edición de campos del producto existente
- **Delete**: Eliminación lógica (soft-delete) con `activo = 0`

### Usuarios (Admin)
- **Read**: Listado de todos los usuarios registrados
- **Update**: Cambio de nombre, correo y rol
- **Delete**: Eliminación lógica de usuarios (excepto admin principal)
- **Protección**: No permite eliminar al usuario 'admin' principal

### Carrito de Compras
- Almacenado en sesión del usuario
- AJAX para agregar/remover productos sin recargar página
- Validación de stock en tiempo real
- Notificaciones toast al usuario

---

## 🎨 Diseño Responsivo

### Características:
- ✅ **Menú hamburguesa** en pantallas < 768px
- ✅ **Grid responsivo** para productos (auto-fill, minmax)
- ✅ **Layout flexible** con Flexbox y CSS Grid
- ✅ **Tipografía escalable** con unidades relativas (rem)
- ✅ **Paleta de colores** consistente (naranja #ff5e14, negro #0d0d0d)

### Breakpoints:
- **Desktop**: 1200px+ (grid 4 columnas)
- **Tablet**: 768px - 1199px (grid 2-3 columnas, menú hamburguesa)
- **Móvil**: < 768px (grid 1-2 columnas, menú colapsable)

### Transiciones suaves:
- Hover en elementos interactivos: 0.2s
- Animación de notificaciones: 0.3s
- Rotación del ícono hamburguesa: 0.3s

---

## 📋 Validaciones

### HTML5 Nativa:
- `required`: Campos obligatorios
- `minlength` / `maxlength`: Límites de caracteres
- `type="email"`: Validación de formato de correo
- `type="number"`: Solo números en campos de precio
- `type="url"`: Validación de URLs de imágenes

### JavaScript:
- Validación en tiempo real antes de enviar
- Expresiones regulares para emails
- Manejo de errores con try/catch
- Mensajes de error personalizados al usuario

---

## 🔒 Seguridad

- ✅ **Contraseñas hasheadas**: bcryptjs con salt aleatorio
- ✅ **SQL Injection prevention**: Prepared statements con `?`
- ✅ **Session management**: express-session con cookie segura
- ✅ **Middleware de autenticación**: Protección de rutas privadas
- ✅ **Soft-delete**: Los datos nunca se eliminan completamente
- ✅ **Validación del servidor**: No confiar solo en validación del cliente
- ✅ **Transbank PCI-DSS**: Cumplimiento de estándares de pago

---

## 🎓 Estructura MVC

El proyecto sigue el patrón **Model-View-Controller**:

- **Models** (conceptual): Tablas de BD (`clientes`, `productos`, `detalle_compra`)
- **Views**: Archivos EJS que generan HTML dinámico
- **Controllers**: Lógica de negocio en `/controllers` que conecta rutas con BD

### Flujo típico:
1. Usuario hace request a ruta
2. Ruta en `/routes` llama a función del controlador
3. Controlador ejecuta lógica (consultas BD, validaciones, etc.)
4. Se renderiza una vista EJS con los datos resultantes

---

## 🛠️ Troubleshooting

### "Cannot GET /ruta"
- Verifica que la ruta esté definida en `/routes`
- Comprueba que el controlador existe y está importado

### "Conexión a BD rechazada"
- Verifica que MySQL esté corriendo
- Comprueba credenciales en `config/db.js`
- Asegúrate de haber ejecutado `DB_Tienda_BOBSTRAPS.sql`

### "Login no funciona"
- Comprueba que la tabla `clientes` existe en BD
- Verifica el usuario y contraseña (admin / admin123)
- Revisa la consola del servidor para mensajes de error

### "El carrito se vacía al refrescar"
- Esto es **comportamiento normal**: carrito se almacena en sesión
- Para persistencia permanente, guardaría en BD

---

## 📚 Recursos de referencia

- [Express.js Official Docs](https://expressjs.com/)
- [EJS Template Engine](https://ejs.co/)
- [MySQL2 Documentation](https://github.com/sidorares/node-mysql2)
- [Transbank Webpay Plus](https://www.transbank.cl/developers)
- [MDN Web Docs — JavaScript](https://developer.mozilla.org/es/docs/Web/JavaScript)
- [MDN Web Docs — HTML Semántico](https://developer.mozilla.org/es/docs/Glossary/Semantics)

---

## 📝 Licencia

Este proyecto es de uso educativo. Desarrollado con propósitos académicos.
