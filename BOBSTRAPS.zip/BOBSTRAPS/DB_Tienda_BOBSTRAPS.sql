-- ============================================================
-- DB_Tienda_BOBSTRAPS.sql
-- INSTRUCCIONES:
--   1. Abre DBeaver
--   2. Conectate a MySQL
--   3. Selecciona todo (Ctrl+A) y ejecuta
-- ============================================================

DROP DATABASE IF EXISTS Tienda;
CREATE DATABASE TiendaJO;
USE TiendaJO;

-- Tabla de clientes (usuarios del sistema)
CREATE TABLE clientes (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(100) NOT NULL,
    usuario   VARCHAR(50)  NOT NULL UNIQUE,
    clave     VARCHAR(255) NOT NULL,
    correo    VARCHAR(100),
    telefono  VARCHAR(9),
    role      VARCHAR(20) NOT NULL DEFAULT 'user',
    activo    TINYINT(1) NOT NULL DEFAULT 1,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de productos
CREATE TABLE productos (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(100) NOT NULL,
    descripcion TEXT,
    imagen_url  VARCHAR(255),
    precio      INT NOT NULL,
    stock       INT NOT NULL DEFAULT 0,
    activo      TINYINT(1) NOT NULL DEFAULT 1,
    creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de órdenes y envíos
CREATE TABLE ordenes (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id       INT NOT NULL,
    buy_order        VARCHAR(26) NOT NULL,
    token            VARCHAR(64),
    total            INT NOT NULL,
    shipping_address TEXT,
    shipping_method  VARCHAR(100),
    shipping_cost    INT NOT NULL DEFAULT 0,
    estado           VARCHAR(50) NOT NULL DEFAULT 'pendiente',
    payment_type     VARCHAR(50),
    authorization_code VARCHAR(20),
    response_code    INT,
    transaction_date TIMESTAMP NULL,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Tabla de compras
CREATE TABLE detalle_compra (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    orden_id      INT,
    cliente_id    INT NOT NULL,
    producto_id   INT NOT NULL,
    cantidad      INT NOT NULL,
    precio_unitario INT NOT NULL,
    fecha         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (orden_id)   REFERENCES ordenes(id),
    FOREIGN KEY (cliente_id)  REFERENCES clientes(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Tabla de solicitudes de devolución, cambio y soporte
CREATE TABLE solicitudes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id  INT NOT NULL,
    orden_id    INT NOT NULL,
    producto_id INT NOT NULL,
    tipo        ENUM('devolucion','cambio','soporte') NOT NULL,
    motivo      VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    estado      VARCHAR(30) NOT NULL DEFAULT 'pendiente',
    creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id)  REFERENCES clientes(id),
    FOREIGN KEY (orden_id)    REFERENCES ordenes(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Tabla de contactos (formulario de contacto)
CREATE TABLE contactos (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(100) NOT NULL,
    correo    VARCHAR(100) NOT NULL,
    mensaje   TEXT NOT NULL,
    leido     TINYINT(1) NOT NULL DEFAULT 0,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- USUARIO ADMIN
-- Usuario: admin
-- Contrasena: admin123
-- ============================================================
INSERT INTO clientes (nombre, usuario, clave, correo, telefono, role) VALUES (
    'Administrador',
    'admin',
    '$2a$10$io2ZYbWrn3lijW.XeMFl0enuynbkMMs70nJSjsbE1WFKmoXjjJkOu',
    'admin@bobstraps.cl',
    '912345678',
    'admin'
);

-- ============================================================
-- PRODUCTOS DE EJEMPLO (imagenes de picsum.photos - siempre funcionan)
-- ============================================================
INSERT INTO productos (nombre, descripcion, imagen_url, precio, stock) VALUES

('Mancuernas Ajustables 20kg',
 'Par de mancuernas de acero con disco ajustable. Ideales para entrenamiento en casa.',
 'https://images.pexels.com/photos/7743320/pexels-photo-7743320.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 34990, 12),

('Barra Olimpica 20kg',
 'Barra olimpica de acero forjado. Capacidad maxima 300kg. Longitud 220cm.',
 'https://images.pexels.com/photos/841130/pexels-photo-841130.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 89990, 5),

('Banco de Pesas Multiposicion',
 'Banco ajustable con 7 posiciones. Soporta hasta 250kg. Estructura de acero.',
 'https://images.pexels.com/photos/14623668/pexels-photo-14623668.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 59990, 4),

('Cuerda para Saltar Pro',
 'Cuerda de acero trenzado con rodamientos de precision. Ajustable hasta 3m.',
 'https://images.pexels.com/photos/19185915/pexels-photo-19185915.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 12990, 20),

('Colchoneta Yoga 6mm',
 'Mat antideslizante de PVC ecologico. Medidas 183x61cm. Incluye correa.',
 'https://images.pexels.com/photos/5037407/pexels-photo-5037407.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 18990, 15),

('Pesas Kettlebell 16kg',
 'Kettlebell de hierro fundido con acabado antioxidante. Base plana para mayor estabilidad.',
 'https://images.pexels.com/photos/3837439/pexels-photo-3837439.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 27990, 8),

('Guantes de Entrenamiento',
 'Guantes de cuero con relleno en palma. Velcro ajustable. Tallas S M L XL.',
 'https://images.pexels.com/photos/927437/pexels-photo-927437.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 15990, 25),

('Banda Elastica Kit x5',
 'Set de 5 bandas de resistencia progresiva de 5kg a 40kg. Incluye manijas y ancla de puerta.',
 'https://images.pexels.com/photos/5067740/pexels-photo-5067740.jpeg?w=400&h=300&auto=compress&cs=tinysrgb',
 22990, 10);

-- Verificar datos insertados:
-- SELECT * FROM clientes;
-- SELECT * FROM productos;
