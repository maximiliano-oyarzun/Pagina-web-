// ============================================================
// assets/js/registro.js — Actividad 3.2: Trabajo con DOM y formularios
// ============================================================
// JavaScript puro (sin librerías). Cubre los 5 pilares técnicos:
//
//   1) Formulario con 5 elementos (ver views/registro.ejs)
//   2) Validaciones en tiempo real con el evento 'input'
//   3) Feedback visual: clases CSS (is-valid / is-invalid),
//      íconos, mensajes animados y checklist de contraseña
//   4) Simulación de consulta a BD con 'blur' + setTimeout
//   5) Botón deshabilitado dinámicamente + validación final en submit
//
// Extra visual: la "barra olímpica" del panel izquierdo se carga
// con un par de discos por cada campo válido (manipulación de SVG
// vía DOM, misma técnica que con cualquier otro elemento).
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ──────────────────────────────────────────────────────────
  // 1. REFERENCIAS AL DOM
  //    Capturamos una sola vez los nodos que vamos a manipular.
  // ──────────────────────────────────────────────────────────
  const form        = document.getElementById('form-registro');
  if (!form) return; // Si no estamos en /registro, no hacemos nada

  const inputs = {
    username: document.getElementById('reg-username'),
    email:    document.getElementById('reg-email'),
    password: document.getElementById('reg-password'),
    confirm:  document.getElementById('reg-confirm')
  };

  const btnSubmit   = document.getElementById('btn-registro');
  const passRules   = document.getElementById('pass-rules');
  const stepsList   = document.getElementById('reg-steps');
  const barbellKg   = document.getElementById('barbell-kg');

  const modal       = document.getElementById('modal-exito');
  const modalUser   = document.getElementById('modal-user');
  const btnCerrar   = document.getElementById('btn-cerrar-modal');

  // Estado central de validez. El botón de envío depende de esto.
  const estado = {
    username: false,
    email:    false,
    password: false,
    confirm:  false
  };

  // ──────────────────────────────────────────────────────────
  // 2. EXPRESIONES REGULARES (reglas estrictas de la pauta)
  // ──────────────────────────────────────────────────────────

  // Usuario: solo letras, números y guion bajo (sin caracteres especiales)
  const REGEX_USUARIO = /^[a-zA-Z0-9_]+$/;

  // Email: texto@texto.dominio, sin espacios ni arrobas dobles
  const REGEX_EMAIL = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  // Contraseña: las verificamos por partes para poder iluminar
  // el checklist regla por regla
  const REGEX_MAYUSCULA = /[A-Z]/;
  const REGEX_MINUSCULA = /[a-z]/;
  const REGEX_NUMERO    = /[0-9]/;

  // ──────────────────────────────────────────────────────────
  // 3. "BASE DE DATOS" FICTICIA (para la simulación con blur)
  // ──────────────────────────────────────────────────────────
  const BD_USUARIOS = ['admin', 'bob', 'bobstraps', 'entrenador1', 'maxi_gym', 'sebastian'];
  const BD_CORREOS  = ['admin@bobstraps.cl', 'bob@bobstraps.cl', 'contacto@bobstraps.cl', 'ventas@gmail.com'];

  // ──────────────────────────────────────────────────────────
  // 4. HELPERS DE FEEDBACK VISUAL
  //    Centralizamos la manipulación de clases y mensajes
  //    para no repetir código en cada validador.
  // ──────────────────────────────────────────────────────────

  /** Devuelve el contenedor .field de un input */
  const campoDe = (input) => input.closest('.field');

  /** Marca un campo como válido (borde verde + check) */
  function marcarValido(input) {
    const field = campoDe(input);
    field.classList.add('is-valid');
    field.classList.remove('is-invalid');
    ocultarError(input);
  }

  /** Marca un campo como inválido (borde rojo + cruz + mensaje) */
  function marcarInvalido(input, mensaje) {
    const field = campoDe(input);
    field.classList.add('is-invalid');
    field.classList.remove('is-valid');
    mostrarError(input, mensaje);
  }

  /** Limpia ambos estados (campo vacío / neutro) */
  function marcarNeutro(input) {
    const field = campoDe(input);
    field.classList.remove('is-valid', 'is-invalid');
    ocultarError(input);
  }

  /** Muestra el mensaje de error animado bajo el campo */
  function mostrarError(input, mensaje) {
    const msg = campoDe(input).querySelector('.msg-error');
    msg.textContent = mensaje;
    msg.classList.add('show');
  }

  /** Oculta el mensaje de error */
  function ocultarError(input) {
    const msg = campoDe(input).querySelector('.msg-error');
    msg.classList.remove('show');
  }

  /** Mensaje de la consulta simulada a la BD (verde/rojo/cargando) */
  function mostrarMensajeBD(input, texto, tipo) {
    const msg = campoDe(input).querySelector('.msg-db');
    msg.textContent = texto;
    msg.className = 'msg-db show ' + tipo; // tipo: 'ok' | 'bad' | 'checking'
  }

  function ocultarMensajeBD(input) {
    const msg = campoDe(input).querySelector('.msg-db');
    if (msg) msg.className = 'msg-db';
  }

  // ──────────────────────────────────────────────────────────
  // 5. VALIDADORES POR CAMPO
  //    Cada uno actualiza el estado, el feedback visual
  //    y devuelve true/false.
  // ──────────────────────────────────────────────────────────

  /** Usuario: mínimo 6 caracteres, sin caracteres especiales */
  function validarUsuario() {
    const valor = inputs.username.value.trim();

    if (valor === '') {
      marcarNeutro(inputs.username);
      estado.username = false;
    } else if (valor.length < 6) {
      marcarInvalido(inputs.username, 'El usuario debe tener mínimo 6 caracteres.');
      estado.username = false;
    } else if (!REGEX_USUARIO.test(valor)) {
      marcarInvalido(inputs.username, 'No se permiten caracteres especiales (solo letras, números y _).');
      estado.username = false;
    } else {
      marcarValido(inputs.username);
      estado.username = true;
    }

    actualizarUI();
    return estado.username;
  }

  /** Email: formato estricto vía regex */
  function validarEmail() {
    const valor = inputs.email.value.trim();

    if (valor === '') {
      marcarNeutro(inputs.email);
      estado.email = false;
    } else if (!REGEX_EMAIL.test(valor)) {
      marcarInvalido(inputs.email, 'Ingresa un correo con formato válido (ej: nombre@dominio.cl).');
      estado.email = false;
    } else {
      marcarValido(inputs.email);
      estado.email = true;
    }

    actualizarUI();
    return estado.email;
  }

  /** Contraseña: 8+ caracteres, mayúscula, minúscula y número.
      Además ilumina el checklist regla por regla. */
  function validarPassword() {
    const valor = inputs.password.value;

    const reglas = {
      len:   valor.length >= 8,
      upper: REGEX_MAYUSCULA.test(valor),
      lower: REGEX_MINUSCULA.test(valor),
      num:   REGEX_NUMERO.test(valor)
    };

    // Encendemos/apagamos cada "chip" del checklist
    passRules.querySelectorAll('li').forEach(li => {
      li.classList.toggle('ok', reglas[li.dataset.rule]);
    });

    const todasOk = Object.values(reglas).every(Boolean);

    if (valor === '') {
      marcarNeutro(inputs.password);
      estado.password = false;
    } else if (!todasOk) {
      // Armamos un mensaje específico con lo que falta
      const faltan = [];
      if (!reglas.len)   faltan.push('8 caracteres');
      if (!reglas.upper) faltan.push('una mayúscula');
      if (!reglas.lower) faltan.push('una minúscula');
      if (!reglas.num)   faltan.push('un número');
      marcarInvalido(inputs.password, 'Falta: ' + faltan.join(', ') + '.');
      estado.password = false;
    } else {
      marcarValido(inputs.password);
      estado.password = true;
    }

    // Si la confirmación ya tiene texto, la re-validamos
    // (porque depende del valor de este campo)
    if (inputs.confirm.value !== '') validarConfirm();

    actualizarUI();
    return estado.password;
  }

  /** Confirmación: debe ser idéntica a la contraseña */
  function validarConfirm() {
    const valor = inputs.confirm.value;

    if (valor === '') {
      marcarNeutro(inputs.confirm);
      estado.confirm = false;
    } else if (valor !== inputs.password.value) {
      marcarInvalido(inputs.confirm, 'Las contraseñas no coinciden.');
      estado.confirm = false;
    } else {
      marcarValido(inputs.confirm);
      estado.confirm = true;
    }

    actualizarUI();
    return estado.confirm;
  }

  // ──────────────────────────────────────────────────────────
  // 6. SIMULACIÓN DE CONSULTA A BASE DE DATOS (evento blur)
  //    setTimeout simula la latencia de una petición real.
  // ──────────────────────────────────────────────────────────

  function consultarDisponibilidad(input, listaBD, etiqueta) {
    const valor = input.value.trim().toLowerCase();
    const field = campoDe(input);

    // Solo consultamos si el campo pasó su validación de formato
    if (valor === '' || field.classList.contains('is-invalid')) {
      ocultarMensajeBD(input);
      return;
    }

    // Estado "consultando": spinner + texto gris
    field.classList.add('is-checking');
    mostrarMensajeBD(input, 'Consultando disponibilidad…', 'checking');

    // Simulamos la latencia de la BD (900 ms)
    setTimeout(() => {
      field.classList.remove('is-checking');

      const ocupado = listaBD.includes(valor);

      if (ocupado) {
        // Mensaje exacto exigido por la pauta
        mostrarMensajeBD(input, etiqueta + ' no disponible', 'bad');
        marcarInvalido(input, 'Ese ' + etiqueta.toLowerCase() + ' ya está registrado, prueba con otro.');
        estado[input === inputs.username ? 'username' : 'email'] = false;
      } else {
        mostrarMensajeBD(input, etiqueta + ' disponible', 'ok');
      }

      actualizarUI();
    }, 900);
  }

  // ──────────────────────────────────────────────────────────
  // 7. UI GLOBAL: botón de envío + barra olímpica + pasos
  // ──────────────────────────────────────────────────────────

  function actualizarUI() {
    const validos = Object.values(estado).filter(Boolean).length;
    const todoOk  = validos === 4;

    // (Pilar 5) El botón se deshabilita si algo es inválido o está vacío
    btnSubmit.disabled = !todoOk;

    // Barra olímpica: encendemos un par de discos por campo válido.
    // Orden fijo para que la barra se cargue de adentro hacia afuera.
    const orden = ['username', 'email', 'password', 'confirm'];
    orden.forEach((campo, i) => {
      const n = i + 1;
      const ok = estado[campo];
      document.getElementById('plateL' + n)?.classList.toggle('lifted', ok);
      document.getElementById('plateR' + n)?.classList.toggle('lifted', ok);

      // Lista de pasos del panel izquierdo
      stepsList?.querySelector(`li[data-step="${campo}"]`)?.classList.toggle('done', ok);
    });

    barbellKg.textContent = validos;
  }

  // ──────────────────────────────────────────────────────────
  // 8. REGISTRO DE EVENTOS
  // ──────────────────────────────────────────────────────────

  // (Pilar 2) Validación en tiempo real mientras se escribe
  inputs.username.addEventListener('input', () => {
    ocultarMensajeBD(inputs.username); // si edita, la consulta anterior caduca
    validarUsuario();
  });

  inputs.email.addEventListener('input', () => {
    ocultarMensajeBD(inputs.email);
    validarEmail();
  });

  inputs.password.addEventListener('input', validarPassword);
  inputs.confirm.addEventListener('input', validarConfirm);

  // (Pilar 4) Consulta simulada a la BD al perder el foco
  inputs.username.addEventListener('blur', () => {
    consultarDisponibilidad(inputs.username, BD_USUARIOS, 'Nombre de usuario');
  });

  inputs.email.addEventListener('blur', () => {
    consultarDisponibilidad(inputs.email, BD_CORREOS, 'Correo electrónico');
  });

  // Botones "ver contraseña" (alternan el type del input)
  document.querySelectorAll('.toggle-pass').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.target);
      const visible = target.type === 'text';
      target.type = visible ? 'password' : 'text';
      btn.classList.toggle('active', !visible);
      target.focus();
    });
  });

  // ──────────────────────────────────────────────────────────
  // 9. (Pilar 5) VALIDACIÓN FINAL EN EL SUBMIT
  // ──────────────────────────────────────────────────────────
  form.addEventListener('submit', (e) => {
    // Re-validamos TODO por seguridad
    const okUsuario  = validarUsuario();
    const okEmail    = validarEmail();
    const okPassword = validarPassword();
    const okConfirm  = validarConfirm();

    // Si hay algún fallo, prevenimos el envío y mostramos feedback
    if (!(okUsuario && okEmail && okPassword && okConfirm)) {
      e.preventDefault();
      return;
    }
    // Si todo está OK, permitimos que el formulario sea enviado al servidor
    // (el servidor creará el usuario y redirigirá al login)
  });

  // Cierre del modal (botón, clic fuera o tecla Escape)
  btnCerrar.addEventListener('click', cerrarModal);
  modal.addEventListener('click', (e) => { if (e.target === modal) cerrarModal(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) cerrarModal();
  });

  function cerrarModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    form.reset();

    // Volvemos todo al estado inicial
    Object.values(inputs).forEach(marcarNeutro);
    Object.keys(estado).forEach(k => estado[k] = false);
    passRules.querySelectorAll('li').forEach(li => li.classList.remove('ok'));
    document.querySelectorAll('.msg-db').forEach(m => m.className = 'msg-db');
    actualizarUI();
  }

  // Estado inicial: botón deshabilitado y barra vacía
  actualizarUI();

  // Si el servidor indicó que el registro fue exitoso, abrimos el modal
  // (el servidor define window._registro_success cuando renderiza la vista)
  if (window._registro_success && window._registro_success.user) {
    modalUser.textContent = window._registro_success.user;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    btnCerrar.focus();
    // limpiamos la bandera para evitar reabrirlo en re-render
    delete window._registro_success;
  }
});


/* ============================================================
   APOYO ACADÉMICO — PREGUNTAS DE CIERRE (Actividad 3.2)
   ============================================================

   1) ¿Qué aprendiste de la actividad realizada?

   Aprendí a manipular el DOM de forma directa para construir
   validaciones en tiempo real sin depender de librerías. Antes
   entendía los eventos como algo aislado, pero acá vi cómo
   'input' y 'blur' cumplen roles distintos: uno valida mientras
   el usuario escribe y el otro sirve para acciones más "caras"
   como consultar la base de datos. También afiancé el uso de
   expresiones regulares para definir reglas estrictas (formato
   de email, composición de la contraseña) y entendí la
   importancia de centralizar el estado del formulario en un
   objeto JavaScript, porque eso permite que el botón de envío,
   los íconos y los mensajes reaccionen de forma coherente.

   2) ¿En qué ámbitos puedes utilizar o aplicar lo realizado?

   Esto se aplica directo en cualquier sistema con registro o
   inicio de sesión: tiendas online, intranets, paneles de
   administración o apps de servicios. La validación en el
   cliente mejora la experiencia de usuario y reduce peticiones
   inválidas al servidor, y la verificación de disponibilidad
   con 'blur' es exactamente el patrón que usan plataformas
   reales (con fetch hacia una API en vez de setTimeout). Las
   mismas técnicas de feedback visual sirven para formularios de
   pago, encuestas o cualquier flujo donde el usuario ingrese
   datos críticos.

   3) ¿Cómo contribuyó el trabajo en parejas colaborativas a tu
      aprendizaje durante la actividad?

   Trabajar en pareja nos obligó a dividir responsabilidades y a
   explicar nuestras decisiones en voz alta, lo que ayuda mucho
   a detectar errores de lógica antes de probarlos. Mientras uno
   programaba los validadores, el otro revisaba los casos borde
   (¿qué pasa si la contraseña cambia después de confirmarla?) y
   así descubrimos detalles que solos se nos habrían pasado.
   Además, comparar estilos de código nos sirvió para acordar
   convenciones comunes, como centralizar el feedback visual en
   funciones helper en lugar de repetir clases por todos lados.

   4) ¿Qué aspectos del manejo del DOM y formularios te
      resultaron más desafiantes y cómo los superaste?

   Lo más desafiante fue la dependencia entre campos: la
   confirmación de contraseña queda inválida si el usuario
   vuelve atrás y edita la contraseña original. Lo resolvimos
   re-validando la confirmación dentro del validador de la
   contraseña. El segundo desafío fue la asincronía de la
   consulta simulada: había que mostrar un estado de "cargando",
   invalidar la consulta si el usuario seguía escribiendo y
   actualizar el botón de envío recién cuando llegaba la
   respuesta del setTimeout. Entender ese flujo asíncrono y
   mantener el estado consistente fue lo que más nos hizo
   investigar y probar.

   ============================================================ */
