// ============================================================
// assets/js/main.js — JavaScript del lado del cliente
// ============================================================
// Este archivo corre en el NAVEGADOR del usuario (no en el servidor).
// Aquí hacemos validaciones de formularios antes de enviarlos.
// ============================================================

// ── Esperar a que el HTML esté cargado ─────────────────────
// DOMContentLoaded se dispara cuando el HTML está listo
document.addEventListener('DOMContentLoaded', () => {

  // ── Menú hamburguesa responsivo ────────────────────────
  const navbarToggle = document.getElementById('navbar-toggle');
  const navbarMenu = document.getElementById('navbar-menu');
  
  if (navbarToggle && navbarMenu) {
    navbarToggle.addEventListener('click', () => {
      navbarToggle.classList.toggle('active');
      navbarMenu.classList.toggle('active');
    });
    
    // Cerrar menú al hacer click en un enlace
    navbarMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navbarToggle.classList.remove('active');
        navbarMenu.classList.remove('active');
      });
    });
  }

  // ── Validación del formulario de contacto ──────────────
  const formContacto = document.getElementById('form-contacto');
  if (formContacto) {
    formContacto.addEventListener('submit', (e) => {
      // Obtenemos los valores de los campos
      const nombre = document.getElementById('nombre').value.trim();
      const correo = document.getElementById('correo').value.trim();
      const mensaje = document.getElementById('mensaje').value.trim();

      // Validamos que no estén vacíos
      if (!nombre || !correo || !mensaje) {
        e.preventDefault(); // Evita que el formulario se envíe
        mostrarError('formContacto-error', 'Por favor completa todos los campos');
        return;
      }

      // Validamos el formato del correo con una expresión regular
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(correo)) {
        e.preventDefault();
        mostrarError('formContacto-error', 'Ingresa un correo electrónico válido');
        return;
      }

      // Si todo está bien, el formulario se envía normalmente
    });
  }

  // ── Validación del formulario de login ─────────────────
  const formLogin = document.getElementById('form-login');
  if (formLogin) {
    formLogin.addEventListener('submit', (e) => {
      const usuario = document.getElementById('usuario').value.trim();
      const clave = document.getElementById('clave').value;

      if (!usuario || !clave) {
        e.preventDefault();
        mostrarError('formLogin-error', 'Ingresa usuario y contraseña');
      }
    });
  }

  // ── Validación del formulario del panel ────────────────
  const formPanel = document.getElementById('form-panel');
  if (formPanel) {
    formPanel.addEventListener('submit', (e) => {
      const nombre = document.getElementById('prod-nombre').value.trim();
      const precio = document.getElementById('prod-precio').value;

      if (!nombre) {
        e.preventDefault();
        mostrarError('formPanel-error', 'El nombre del producto es obligatorio');
        return;
      }

      // El precio debe ser un número mayor que 0
      if (!precio || isNaN(precio) || Number(precio) <= 0) {
        e.preventDefault();
        mostrarError('formPanel-error', 'Ingresa un precio válido mayor a 0');
      }
    });
  }

  // ── Control de cantidad en productos ───────────────────
  const qtyMinusButtons = document.querySelectorAll('.qty-minus');
  const qtyPlusButtons = document.querySelectorAll('.qty-plus');

  qtyMinusButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const input = btn.nextElementSibling;
      let value = parseInt(input.value);
      if (value > 1) {
        input.value = value - 1;
      }
    });
  });

  qtyPlusButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const input = btn.previousElementSibling;
      let value = parseInt(input.value);
      input.value = value + 1;
    });
  });

  // ── Agregar al carrito con AJAX ────────────────────────
  const addToCartForms = document.querySelectorAll('.add-to-cart-form');
  addToCartForms.forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      const body = new URLSearchParams(formData);

      try {
        const response = await fetch('/cart/add', {
          method: 'POST',
          body,
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        });
        const data = await response.json();

        if (data.success) {
          mostrarNotificacion(data.message, 'exito');
        } else {
          mostrarNotificacion(data.message || 'Error al agregar al carrito', 'error');
        }
      } catch (err) {
        console.error('Error:', err);
        mostrarNotificacion('Error al procesar la solicitud', 'error');
      }
    });
  });

  const shippingMethod = document.getElementById('shipping_method');
  const shippingCostLabel = document.getElementById('shipping-cost');
  const grandTotalLabel = document.getElementById('grand-total');
  const checkoutForm = document.querySelector('.checkout-form');

  if (shippingMethod && shippingCostLabel && grandTotalLabel && checkoutForm) {
    const subtotalValue = Number(checkoutForm.dataset.subtotal || 0);

    function updateShippingTotal() {
      const method = shippingMethod.value;
      let cost = 3000;
      if (method === 'express') cost = 7000;
      if (method === 'retiro') cost = 0;
      shippingCostLabel.textContent = `$${cost.toLocaleString('es-CL')}`;
      grandTotalLabel.textContent = `$${(subtotalValue + cost).toLocaleString('es-CL')}`;
    }

    shippingMethod.addEventListener('change', updateShippingTotal);
    updateShippingTotal();
  }

});

// ── Función para mostrar notificaciones ───────────────────
function mostrarNotificacion(mensaje, tipo = 'exito') {
  // Crear elemento de notificación
  const notif = document.createElement('div');
  notif.className = `notificacion notificacion-${tipo}`;
  notif.textContent = mensaje;
  
  document.body.appendChild(notif);
  
  // Trigger animation
  setTimeout(() => notif.classList.add('mostrar'), 10);
  
  // Remover después de 3 segundos
  setTimeout(() => {
    notif.classList.remove('mostrar');
    setTimeout(() => notif.remove(), 300);
  }, 3000);
}

// ── Función auxiliar para mostrar errores ─────────────────────
// Busca un elemento por su ID y muestra el mensaje de error.
function mostrarError(elementId, mensaje) {
  const el = document.getElementById(elementId);
  if (el) {
    el.textContent = mensaje;
    el.style.display = 'block'; // Muestra el elemento (por defecto está oculto)
  }
}
